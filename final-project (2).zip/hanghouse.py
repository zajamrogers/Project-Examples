# Ken Potter, Mark Poplawski,
# Zack Rogers, Kayode Ogunmakinwa
# SDEV 220
# HangHouse
# Due December 19, 2020

import random
from tkinter import *


def keyPressed(event):
    global count, latestStr, missedLetters, found

    current = event.char

    # Check for invalid input
    if not current.isalpha():
        return

    # Check if input is already guessed
    if current in missedLetters:
        return

    if current in word:

        latestStr_list = list(latestStr.replace(" ", ""))
        for i in range(0, len(word)):
            if word[i] == current:
                latestStr_list[i] = word[i]
        latestStr = ''.join(latestStr_list)

        msg1 = "Guess a word: " + latestStr
        msg2 = "Incorrect letters: " + missedLetters

    else:
        missedLetters += (current + '')
        count += 1

        if count < 7:
            msg1 = "Guess a word: " + latestStr
            msg2 = "Incorrect letters: " + missedLetters
        else:
            msg1 = "You lose :(... The word is: " + word
            msg2 = "Press Enter to play again."

    if '*' not in latestStr:
        found = True
        msg1 = "You win!"
        msg2 = "Press Enter to play again."

    draw(count, msg1, msg2)
    return


def draw(count, msg1, msg2):
    canvas.delete("house")
    canvas.width = 400
    canvas.height = 500

    if count >= 1:
        canvas.create_rectangle(50, 125, 350, 325, tags="house")
    if count >= 2:
        canvas.create_polygon(30, 125, 200, 10, 370, 125,
                              outline='black', fill='', tags="house")
    if count >= 3:
        canvas.create_rectangle(70, 140, 120, 230, tags="house")
        canvas.create_line(95, 140, 95, 230, tags="house")
        canvas.create_line(70, 185, 120, 185, tags="house")
    if count >= 4:
        canvas.create_rectangle(280, 140, 330, 230, tags="house")
        canvas.create_line(305, 140, 305, 230, tags="house")
        canvas.create_line(280, 185, 330, 185, tags="house")
    if count >= 5:
        canvas.create_rectangle(170, 170, 230, 295, tags="house")
    if count >= 6:
        canvas.create_rectangle(140, 295, 260, 310, tags="house")
        canvas.create_rectangle(130, 310, 270, 325, tags="house")
    if count >= 7:
        canvas.create_line(280, 64, 280, 30, tags="house")
        canvas.create_line(280, 30, 305, 30, tags="house")
        canvas.create_line(305, 30, 305, 81, tags="house")

    #Messages
    canvas.create_text(200, size-50, text=msg1, tags="house", font=12)
    canvas.create_text(200, size-30, text=msg2, tags="house", font=12)


# Begin game
def beginGame():
    global count, latestStr, word, missedLetters

    # Get a random word form the list
    word = random.choice(words)
    print(word)
    latestStr = "*" * len(word)
    count = 0
    missedLetters = ''
    msg1 = "Guess a word: " + latestStr
    msg2 = ""

    # Draw the house
    draw(count, msg1, msg2)


# Play again
def playAgain(event):
    global count, found

    if (count < 7 and found == True) or \
            (count == 7 and found == False):
        beginGame()
        count = 0
        found = False


# Global variables
word = ''
latestStr = ''
missedLetters = ''
count = 0
found = False


# Create a window and set title
window = Tk()
window.title("HangHouse")

# Create a canvas for the window
size = 400
canvas = Canvas(window, width=size, height=size)
canvas.pack()

# Get list of words
infile = open("words.txt", "r")
w = []
words = []
for line in infile:
    w.append(line)
infile.close()

for i in w:
    words.append(i.strip())

print(words)

beginGame()

# Keep playing
canvas.focus_set()
canvas.bind('<Return>', playAgain)
canvas.bind('<Key>', keyPressed)

window.mainloop()
